export const ROOT = "http://localhost:8080/api/v1";
export const TRANSACTIONS = `${ROOT}/transactions`;
