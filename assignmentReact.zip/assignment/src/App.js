import "./App.css";
import AppWrapper from "./components/AppWrapper";

function App() {
  return (
    <div className="App">
      <AppWrapper />
    </div>
  );
}

export default App;
